import time


def test_search_by_price_filter(search_page):
    search_page.open_page()
    search_page.cookie_accept()
    search_page.field_price_from("3000")
    time.sleep(2)
    search_page.field_price_to("5000")
    time.sleep(2)
    search_page.field_year_from("2000")
    search_page.field_year_to("2007")
    search_page.press_button_search()
    search_page.check_change_url()

