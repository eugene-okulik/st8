import time


def login_ok(login_page):
    login_page.open_page()
    time.sleep(2)
    login_page.cookie_accept()
    login_page.check_button_phone()
    login_page.set_phone('0885021332')
    login_page.set_password('Fn2RruvgQvqDr')
    login_page.click_on_create_button()
    login_page.check_account_name_visible()



def login_error_radiobutton(login_page):
    login_page.open_page()
    login_page.cookie_accept()
    login_page.check_button_phone()
    login_page.check_phone_when_email_is_selected()
    login_page.set_phone('0885021332')
    time.sleep(2)
    login_page.set_password('Fn2RruvgQvqDr')
    login_page.click_on_create_button()
    login_page.check_if_radiobutton_error_visible()


def login_failed_message(login_page):
    login_page.open_page()
    login_page.cookie_accept()
    login_page.check_button_phone()
    login_page.set_phone('0885021332')
    login_page.set_password('Fn2RruqDr4')
    login_page.click_on_create_button()
    time.sleep(2)
    login_page.check_login_failed_message()

def phone_message(login_page):
    login_page.open_page()
    login_page.cookie_accept()
    login_page.check_button_phone()
    login_page.set_phone('08851332344')
    login_page.set_password('Fn2RruqDr4')
    login_page.click_on_create_button()
    time.sleep(2)
    login_page.check_invalid_phone_message()

