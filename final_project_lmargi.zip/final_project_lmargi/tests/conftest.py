import pytest
from selenium import webdriver
from final_project_lmargi.pages.login_page import LoginPage
from  final_project_lmargi.pages.search_page import SearchPage



@pytest.fixture()
def driver():
    driver = webdriver.Chrome()
    driver.maximize_window()
    yield driver
    driver.quit()

@pytest.fixture()
def login_page(driver):
    return LoginPage(driver)


@pytest.fixture()
def search_page(driver):
    return SearchPage(driver)


