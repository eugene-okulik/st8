from selenium.webdriver.common.by import By

COOKIE_ELEMENT = (By.ID, 'cookiescript_accept')
BUTTON_WITH_PHONE = (By.CSS_SELECTOR, 'input[name="regtype"][value="2"]')
EMAIL_INPUT = (By.NAME, 'email_phone')
PASSWORD = (By.NAME, 'passw')
BUTTON_SUBMIT= (By.CLASS_NAME, 'btBlue')
BUTTON_WITH_EMAIL = (By.CSS_SELECTOR, 'input[name="regtype"][value="1"]')
ERROR_MESSAGE_LOGIN = (By.CSS_SELECTOR, "span[style='color:#F00']")
LOGIN_FAILED_MESSAGE = (By.CLASS_NAME, 'regMessage ')
INVALID_PHONE_MESSAGE = (By.CSS_SELECTOR, "span[style='color:#F00']")
ACCOUNT_NAME = ((By.CSS_SELECTOR, "span.clever-link"))
