from selenium.webdriver.common.by import By

COOKIE_ELEMENT = (By.ID, 'cookiescript_accept')
DROPDOWN_PRICE_1 = (By.ID, 'pr1S')
DROPDOWN_PRICE_2 = (By.ID, 'pr2S')
BUTTON_MAKE_A_SELECTION= (By.CLASS_NAME, "uk-button-primary")
DROPDOWN_YEAR_1 = (By.NAME, 'year')
DROPDOWN_YEAR_2 = (By.NAME, 'year1')
SELECTION_TAB = (By.XPATH, '//div[text()="Подбор"]')
INPUT_NUMBER = (By.XPATH, "(//input[@class='InputNumber'])[1]")
INPUT_NUMBER_2 = (By.XPATH, "(//input[@class='InputNumber'])[2]")
BUTTON_SUBMIT_SEARCH = (By.CSS_SELECTOR, "button[type='submit']")

