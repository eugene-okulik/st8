from selenium.common import NoSuchElementException, TimeoutException
from selenium.webdriver.support.wait import WebDriverWait

from final_project_lmargi.pages.base_page import BasePage
from final_project_lmargi.pages.locators import locator_login as locator
from selenium.webdriver.support import expected_conditions as ec


# Авторизация/Логин (7 тестов):
#сделаны:
# Проверка корректности логина (положительный сценарий).
# Проверка с некорректной радио кнопкой (вместо телефона, выбрана почта).
# Проверка с неправильными учетными данными  и сообщением о неуспешном входе
# Проверка на правильность вывода сообщения при вводе неверного пароля.


# нет:
# Проверка с пустыми полями логина.
# Проверка восстановления пароля.
# Проверка выхода из аккаунта (Logout).


class LoginPage(BasePage):

    def open_page(self):
        self.open_by_url('login')

    def cookie_accept(self):
        cookie_element = self.find(locator.COOKIE_ELEMENT)
        cookie_element.click()
        WebDriverWait(self.driver, 10).until(ec.element_to_be_clickable(cookie_element))

    def check_button_phone(self):
        try:
            input_radiobutton = self.find(locator.BUTTON_WITH_PHONE)

            WebDriverWait(self.driver, 10).until(ec.element_to_be_clickable(input_radiobutton))
            input_radiobutton.click()
            assert input_radiobutton, "Phone button click failed"
        except NoSuchElementException:
            assert False, "Phone button not found on the page"
        except TimeoutException:
            assert False, "Phone button is not clickable"


    def set_phone(self, value):
        input_element = self.find(locator.EMAIL_INPUT)
        input_element.click()
        input_element.send_keys(value)


    def set_password(self, value):
        input_element = self.find(locator.PASSWORD)
        input_element.click()
        input_element.send_keys(value)


    def click_on_create_button(self):
        button_element = self.find(locator.BUTTON_SUBMIT)
        button_element.click()

    def check_account_name_visible(self):
        element = self.find(locator.ACCOUNT_NAME)
        assert element.is_displayed(), "Account name is not visible"
        account_name = element.text
        print(f" Имя'{account_name}' найдена")


    def check_phone_when_email_is_selected(self):
        email_radiobutton = self.find(locator.BUTTON_WITH_EMAIL)
        email_radiobutton.click()


    def check_if_radiobutton_error_visible(self):
        error_message = self.find(locator.ERROR_MESSAGE_LOGIN)
        assert error_message.is_displayed(), "Ошибка выбора метода входа не была показана"


    def check_login_failed_message(self):
        login_failed_message =  self.find(locator.LOGIN_FAILED_MESSAGE)
        assert login_failed_message.is_displayed(), "Ошибка входа не была показана"

    def check_invalid_phone_message(self):
        phone_message = self.find(locator.INVALID_PHONE_MESSAGE)
        assert phone_message.is_displayed(), "Сообщение о неверном телефоне  не было показана"


