import time

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains

from final_project_lmargi.pages.base_page import BasePage
from final_project_lmargi.pages.locators import  locator_search as locator
from selenium.webdriver.support import expected_conditions as ec


class SearchPage(BasePage):

    def open_page(self):
        self.open_by_url('search')

    def cookie_accept(self):
        cookie_element = self.find(locator.COOKIE_ELEMENT)
        cookie_element.click()
        WebDriverWait(self.driver, 10).until(ec.element_to_be_clickable(cookie_element))


    def select_option(self, value, price_locator):
        select_ui_element = self.find(price_locator)
        select_ui_element.click()
        actions = ActionChains(self.driver)
        actions.move_to_element(select_ui_element).perform()
        options = WebDriverWait(self.driver, 10).until(
            ec.presence_of_all_elements_located((By.TAG_NAME, "option"))
        )
        assert options, "Опции в выпадающем списке не найдены"

        print(f"Шаг 5: Поиск опции с значением '{value}'")
        option_found = False
        for option in options:
            if option.get_attribute("value").strip()  == value:
                option.click()
                option_found = True
                print(f"Опция с значением '{value}' найдена и выбрана")


        assert option_found, f"Опция с значением '{value}' не найдена"


    def field_price_from(self, value):
        self.select_option(value, locator.DROPDOWN_PRICE_1)

    def field_price_to(self, value):
        self.select_option(value, locator.DROPDOWN_PRICE_2)

    def field_year_from(self, value):
        self.select_option(value, locator.DROPDOWN_YEAR_1)

    def field_year_to(self, value):
        self.select_option(value, locator.DROPDOWN_YEAR_2)

    def press_button_search(self):
        select_ui_element = self.find(locator.BUTTON_SUBMIT_SEARCH)
        select_ui_element.click()

    def check_change_url(self):
        current_url_before = self.driver.current_url
        self.press_button_search()
        WebDriverWait(self.driver, 10).until(
            ec.url_changes(current_url_before)
        )
        current_url_after = self.driver.current_url
        assert current_url_before != current_url_after, "URL не изменился после применения фильтра"





