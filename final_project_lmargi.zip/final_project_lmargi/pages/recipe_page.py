from final_project_lmargi.pages.base_page import BasePage
from final_project_lmargi.pages.locators import locator_recipe as locator
from selenium.webdriver.common.by import By